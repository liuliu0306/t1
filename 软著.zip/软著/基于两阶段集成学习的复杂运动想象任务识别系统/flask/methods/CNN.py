# -*- coding: utf-8 -*-
"""
Created on Sun Jun 26 09:42:41 2022

@author: liurh
"""
# In[ ]:


# import libraries
import numpy as np
import os
import inspect
import _pickle
import mne
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader,TensorDataset
from sklearn.model_selection import train_test_split
from scipy import signal

import tools
# for getting summary info on models
# from torchsummary import summary

import matplotlib.pyplot as plt
from IPython import display
display.set_matplotlib_formats('svg')


def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn


mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

t = [500, 1000]
f_low, f_high = 10, 14

def load(sub=1, train=True):

    f1 = open(f'../train/S0{sub}/block_1.pkl','rb+')
    f2 = open(f'../train/S0{sub}/block_2.pkl','rb+')
    f3 = open(f'../train/S0{sub}/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names

def band_Filter(data, f_low, f_high):
    nyquist = 125
    frange = [f_low, f_high]
    b, a = signal.butter(5, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data
# # Import and process the data



# import dataset (comes with colab!)
"""
sub = 1
data, label, _ = load(sub)

f_low, f_high = 8, 13
label = label-201
n_trials = data.shape[0]
n_channels = data.shape[1]
# TODO: normalize-ignore

for ti in range(n_trials):
    data[ti] = band_Filter(data[ti], f_low, f_high)


brain_network = np.zeros([n_trials, n_channels, n_channels])
for ti in range(n_trials):
    brain_network[ti] = tools.get_brian_network(data[ti], 'plv')
"""
sub = 1
data, label, _ = load(sub)
n_trials = data.shape[0]

for ti in range(n_trials):
    data[ti] = band_Filter(data[ti], f_low, f_high)

label = label-201
# data = np.load('C:/Users/DELL/Desktop/competition/mi_debug/use_2.npy')

_del = np.where(label==0)[0]
label = np.delete(label, _del)
label = label - 1
# label[np.where(label==2)[0]] = 1
data = np.delete(data, _del, axis = 0)


# brain_network = np.mean(brain_network, 0)

# plt.figure()
# plt.imshow(brain_network[:10,:10])
# plt.show()
#%%
# NEW: reshape to 2D!
# brain_network = brain_network.reshape(brain_network.shape[0],1,brain_network.shape[1],brain_network.shape[2])
data = data.reshape(data.shape[0],1,data.shape[1],data.shape[2])
data = torch.from_numpy(data)
data = F.interpolate(data, scale_factor=0.2)
#%%


#%%
# # Create train/test groups using DataLoader
# Step 1: convert to tensor
dataT   = data.float()
labelsT = torch.tensor( label ).long()

# Step 2: use scikitlearn to split the data
train_data,test_data, train_labels,test_labels = train_test_split(dataT, labelsT, test_size=.3)


# Step 3: convert into PyTorch Datasets
train_data = TensorDataset(train_data,train_labels)
test_data  = TensorDataset(test_data,test_labels)

# Step 4: translate into dataloader objects
batchsize    = 16
train_loader = DataLoader(train_data,batch_size=batchsize,shuffle=True,drop_last=False)
test_loader  = DataLoader(test_data,batch_size=test_data.tensors[0].shape[0])



# check size (should be images X channels X width X height)
print(train_loader.dataset.tensors[0].shape)


# # Create the DL model

# In[ ]:


# create a class for the model
def createTheMNISTNet(printtoggle=False):

  class mnistNet(nn.Module):
    def __init__(self,printtoggle):
      super().__init__()

      ### convolution layers
      self.conv1 = nn.Conv2d(1,32,kernel_size=3,stride=1,padding=1)

      self.conv2 = nn.Conv2d(32,64,kernel_size=3,stride=1,padding=1)


      # compute the number of units in FClayer (number of outputs of conv2)
      # expectSize = np.floor( (5+2*0-1)/1 ) + 1 # fc1 layer has no padding or kernel, so set to 0/1
      # expectSize = 20*int(expectSize**2)
      
      ### fully-connected layer
      # self.fc1 = nn.Linear(11200,1000)

      self.fc2 = nn.Linear(3200,100)


      ### output layer
      self.out = nn.Linear(100,2)

      # toggle for printing out tensor sizes during forward prop
      self.print = printtoggle

    # forward pass
    def forward(self,x):
      
      print(f'Input: {x.shape}') if self.print else None

      # convolution -> maxpool -> relu
      x = F.relu(F.max_pool2d(self.conv1(x),2))
      print(f'Layer conv1/pool1: {x.shape}') if self.print else None

      # and again: convolution -> maxpool -> relu
      x = F.relu(F.max_pool2d(self.conv2(x),2))
      print(f'Layer conv2/pool2: {x.shape}') if self.print else None

      # x = F.relu(F.max_pool2d(self.conv3(x),2))

      # reshape for linear layer
      nUnits = x.shape.numel()/x.shape[0]
      x = x.view(-1,int(nUnits))
      if self.print: print(f'Vectorize: {x.shape}')
      
      # linear layers
      # x = F.relu(self.fc1(x))
      x = F.relu(self.fc2(x))
      # x = F.dropout(x, p=0.3, training=self.training)
      if self.print: print(f'Layer fc1: {x.shape}')
      x = self.out(x)
      if self.print: print(f'Layer out: {x.shape}')

      return x
  
  # create the model instance
  net = mnistNet(printtoggle)
  
  # loss function
  lossfun = nn.CrossEntropyLoss()

  # optimizer
  optimizer = torch.optim.Adam(net.parameters(),lr=.001)

  return net,lossfun,optimizer



# test the model with one batch
net,lossfun,optimizer = createTheMNISTNet(True)

X,y = iter(train_loader).next()
yHat = net(X)

# check sizes of model outputs and target variable
print(' ')
print(yHat.shape)
print(y.shape)

# now let's compute the loss
loss = lossfun(yHat,y)
print(' ')
print('Loss:')
print(loss)


# In[ ]:


# a function that trains the model

def function2trainTheModel():

  # number of epochs
  numepochs = 35
  
  # create a new model
  net,lossfun,optimizer = createTheMNISTNet()

  # initialize losses
  losses    = torch.zeros(numepochs)
  trainAcc  = []
  testAcc   = []


  # loop over epochs
  for epochi in range(numepochs):

    # loop over training data batches
    net.train()
    batchAcc  = []
    batchLoss = []
    for X,y in train_loader:

      # forward pass and loss
      yHat = net(X)
      loss = lossfun(yHat,y)

      # backprop
      optimizer.zero_grad()
      loss.backward()
      optimizer.step()

      # loss from this batch
      batchLoss.append(loss.item())

      # compute accuracy
      matches = torch.argmax(yHat,axis=1) == y     # booleans (false/true)
      matchesNumeric = matches.float()             # convert to numbers (0/1)
      accuracyPct = 100*torch.mean(matchesNumeric) # average and x100
      batchAcc.append( accuracyPct )               # add to list of accuracies
    # end of batch loop...

    # now that we've trained through the batches, get their average training accuracy
    trainAcc.append( np.mean(batchAcc) )

    # and get average losses across the batches
    losses[epochi] = np.mean(batchLoss)

    # test accuracy
    net.eval()
    X,y = next(iter(test_loader)) # extract X,y from test dataloader
    with torch.no_grad(): # deactivates autograd
      yHat = net(X)
      
    # compare the following really long line of code to the training accuracy lines
    testAcc.append( 100*torch.mean((torch.argmax(yHat,axis=1)==y).float()) )
    msg = f'Epochs {epochi+1}/{numepochs}'
    sys.stdout.write('\r' + msg)
  # end epochs

  # function output
  return trainAcc,testAcc,losses,net


# # Run the model and show the results!

# In[ ]:


trainAcc,testAcc,losses,net = function2trainTheModel()


# In[ ]:


fig,ax = plt.subplots(1,2,figsize=(16,5))

ax[0].plot(losses,'s-')
ax[0].set_xlabel('Epochs')
ax[0].set_ylabel('Loss')
ax[0].set_title('Model loss')

ax[1].plot(trainAcc,'s-',label='Train')
ax[1].plot(testAcc,'o-',label='Test')
ax[1].set_xlabel('Epochs')
ax[1].set_ylabel('Accuracy (%)')
ax[1].set_title(f'Final model test accuracy: {testAcc[-1]:.2f}%')
ax[1].legend()

plt.show()



