# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 14:17:21 2022

@author: liurh
"""

import os
import inspect
import _pickle
import numpy as np
import mne
from mne.time_frequency import tfr_morlet
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from scipy import signal
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)
import tools

t = [500, 1500]
f_low, f_high = 8, 30
rs = 12587
sub = 1

epochs = tools.to_epoch(*tools.load(sub, t))

n_trials, n_channels, n_timepoints = epochs.get_data().shape

epochs['foot'].plot_psd(fmax=50, color='g', area_alpha=0.5)
epochs['left'].plot_psd(fmax=50, color='g', area_alpha=0.5)
epochs['right'].plot_psd(fmax=50, color='g', area_alpha=0.5)
# epochs['foot'][0].plot_psd_topomap(tmin=2, tmax=3, cmap='RdBu_r')
# epochs['left'].plot_psd_topomap(tmin=2, tmax=3, cmap='RdBu_r')
# epochs['right'].plot_psd_topomap(tmin=2, tmax=3, cmap='RdBu_r')
















