# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 09:03:37 2022

@author: liurh
"""
import os
import inspect
import sys
import numpy as np
import torch
import mne

import random

import torch
from torch import nn
from torch_geometric.nn import global_mean_pool
from torch_geometric.loader import DataLoader
import torch.nn.functional as F
from torch_geometric.nn import GCNConv

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)
import tools

class GCN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super(GCN, self).__init__()
        torch.manual_seed(12345)
        self.conv1 = GCNConv(3, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.conv3 = GCNConv(hidden_channels, hidden_channels)
        self.conv4 = GCNConv(hidden_channels, hidden_channels)
        
        self.lin = nn.Linear(hidden_channels, 3)

    def forward(self, x, edge_index, edge_weight, batch):
        # 1. Obtain node embeddings 
        x = self.conv1(x, edge_index, edge_weight)
        x = x.relu()
        x = self.conv2(x, edge_index, edge_weight)
        x = x.relu()
        x = self.conv3(x, edge_index, edge_weight)
        x = x.relu()
        x = self.conv4(x, edge_index, edge_weight)
        x = x.relu()

        h = global_mean_pool(x, batch)  # [batch_size, hidden_channels]

        x = F.dropout(h, p=0.3, training=self.training)
        x = self.lin(x)
        
        return x, h


epochs_test = tools.load(train=False)
epochs = tools.load()
epochs.crop(2, 6)
epochs.filter(8, 30)
epochs_test.crop(2, 6)
epochs_test.filter(8, 30)

n_channels = epochs.info['nchan']
n_trials = epochs.__len__()

data = epochs.get_data()
label = epochs.events[:,2]-201

network = np.zeros([n_trials, n_channels, n_channels])
for i in range(n_trials):
    network[i] = tools.get_brian_network(data[i], 'pcc')

psd = tools.psd(data)
de = tools.DE(data)
network = tools.binary(network)
degree = tools.get_degree(network)
x = torch.stack([degree, de, psd], 2)

# for test
n_trials_test = epochs_test.__len__()

data_test = epochs_test.get_data()
label_test = epochs_test.events[:,2]-201

network_test = np.zeros([n_trials_test, n_channels, n_channels])
for i in range(n_trials_test):
    network_test[i] = tools.get_brian_network(data_test[i], 'pcc')

psd = tools.psd(data_test)
de = tools.DE(data_test)
network_test = tools.binary(network_test)
degree = tools.get_degree(network_test)
x_test = torch.stack([degree, de, psd], 2)


data_list = [tools.graph_data(network[i], x[i], label[i]) for i in range(n_trials)]
test = [tools.graph_data(network_test[i], x_test[i], label_test[i]) for i in range(n_trials_test)]
batch_size = 32

random.seed(7)
random.shuffle(data_list)

dataset = DataLoader(data_list, batch_size=n_trials, shuffle=True,drop_last=False)
train_loader = DataLoader(data_list[:75], batch_size=batch_size, shuffle=True,drop_last=False)
test_loader = DataLoader(data_list[75:], batch_size=batch_size, shuffle=False,drop_last=False)

model = GCN(hidden_channels=20)
optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
criterion = torch.nn.CrossEntropyLoss()

def train():
    model.train()
    tmp = []
    for data in train_loader:  # Iterate in batches over the training dataset.
         out, h = model(data.x, data.edge_index, data.edge_attr, data.batch)  # Perform a single forward pass.
         loss = criterion(out, data.y)  # Compute the loss.
         tmp.append(loss.item())
         
         optimizer.zero_grad()  # Clear gradients.
         loss.backward()  # Derive gradients.
         optimizer.step()  # Update parameters based on gradients.
         
    return np.array(tmp)

def test(loader):
     model.eval()

     correct = 0
     for data in loader:  # Iterate in batches over the training/test dataset.
         out, h = model(data.x, data.edge_index, data.edge_attr, data.batch)
         pred = out.argmax(dim=1)  # Use the class with highest probability.
         correct += int((pred == data.y).sum())  # Check against ground-truth labels.

     acc = correct / len(loader.dataset)
     return acc, model
#%%
Acc_tr = []
Acc_te = []
loss = []
best = None
best_acc = 0
n_epochs = 100

for epoch in range(1, n_epochs+1):
    tmp = train()
    loss.append( np.mean(tmp) )
    train_acc = test(train_loader)
    test_acc = test(test_loader)
    
    if train_acc[0] > best_acc:
        best = train_acc[1]
        best_acc = test_acc[0]
        
    Acc_tr.append(train_acc[0])
    Acc_te.append(test_acc[0])
    msg = f'Epochs {epoch}/{n_epochs}'
    sys.stdout.write('\r' + msg)

a = next(iter(dataset))
y_hat, h = best(a.x, a.edge_index, a.edge_attr, a.batch)
tools.plot_cm(a, y_hat)







