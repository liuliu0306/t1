# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 09:42:27 2022

@author: DELL
"""

from cnncopy import use
use(1, [400, 1500], [10, 13]);