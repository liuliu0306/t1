
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 14:46:46 2022

@author: liurh
"""
import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from sklearn.model_selection import ShuffleSplit
from sklearn.pipeline import make_pipeline

filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

def load(sub=1):
    f1 = open('./train/block_1.pkl','rb+')
    f2 = open('./train/block_2.pkl','rb+')
    f3 = open('./train/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])
    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250
    n_trials = 90
    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    start = np.where(trigger == 240)[0]
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    
    events = np.zeros([n_trials, 3], dtype=int)
    
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]
        events[ti] = np.array([2000*ti, 0, label[ti]])
    event_id = {'hand/left':201,'hand/right':202,'foot':203}
    info = mne.create_info(ch_names, srate, ch_types='eeg')
    epochs = mne.EpochsArray(epoch_data, info, events, event_id=event_id)

    return epochs

epochs = load()
epochs.crop(2, 6)
epochs.filter(8, 30)

csp = CSP(n_components=15, reg='diagonal_fixed', norm_trace=False)
csp.fit(  )



#%%
"""
X = epochs.get_data()

y = epochs.events[:,2]-201

cv = ShuffleSplit(n_splits=10, test_size=0.2, random_state=7)
clf = make_pipeline(
    #计算协方差矩阵的方式可选diagonal_fixed或oas, 默认的empirical会报错
    CSP(n_components=15, reg='diagonal_fixed', log=False, norm_trace=False),
    # LinearDiscriminantAnalysis()
    # LogisticRegression()
    SVC(C=1, kernel='rbf')
    )

scores = cross_val_multiscore(estimator=clf,X=X,y=y,cv=cv,scoring='accuracy')

mean = round(np.mean(scores),3)
print(mean)

"""















