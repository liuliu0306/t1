# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 18:41:20 2022

@author: liurh
"""

import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from sklearn.model_selection import ShuffleSplit
from sklearn.pipeline import make_pipeline

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

def load(sub=1, train=True):
    if train:
        f1 = open(f'./train/S0{sub}/Train/block_1.pkl','rb+')
        f2 = open(f'./train/S0{sub}/Train/block_2.pkl','rb+')
        f3 = open(f'./train/S0{sub}/Train/block_3.pkl','rb+')
        data1 = _pickle.load(f1)
        data2 = _pickle.load(f2)
        data3 = _pickle.load(f3)
        data = np.hstack([data1['data'], data2['data'], data3['data']])
    else:
        f1 = open('./TestData/MI/S01/block_4.pkl','rb+')
        f2 = open('./TestData/MI/S01/block_5.pkl','rb+')
        data1 = _pickle.load(f1)
        data2 = _pickle.load(f2)
        data = np.hstack([data1['data'], data2['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250
    if train:
        n_trials = 90
    else:
        n_trials = 60
    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data, label, ch_names

def concat():
    data, label, ch_names = load()

    for i in range(2,6):
        tmp_data = load(i)
        data = np.concatenate([data, tmp_data[0]])
        label = np.concatenate([label, tmp_data[1]])

    return data, label, ch_names

def to_epoch(data, label, ch_names):
    srate = 250
    length = len(data)
    events = np.zeros([length, 3], dtype=int)
    event_id = {'hand/left':201,'hand/right':202,'foot':203}

    for ti in range(length):
        events[ti] = np.array([2000*ti, 0, label[ti]])

    info = mne.create_info(ch_names, srate, ch_types='eeg')
    epochs = mne.EpochsArray(data, info, events, event_id=event_id)
    return epochs

def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features


epochs = to_epoch( *concat() )
epochs_test = to_epoch( *load(1) )

epochs.crop(2.004, 4)
epochs.filter(8, 13,method='iir')
epochs_test.crop(2.004, 4)
# epochs_test.filter(8, 13,method='iir')

tmp = epochs_test.get_data()
label = epochs_test.events[:,2]-201


from scipy import signal
def band_Filter(data):
    # print(bandID)
    # bandID = 1
    nyquist = 250 / 2
    frange = [8, 13]
    b, a = signal.butter(5, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data

for i in range(len(tmp)):
    tmp[i] = band_Filter(tmp[i])


X = epochs.get_data()
y = epochs.events[:,2]

W = []
for i in range(5):
    csp = CSP(n_components=15, reg='diagonal_fixed', norm_trace=False)
    W.append(csp.fit(X[i*90:(i+1)*90], y[i*90:(i+1)*90]).filters_)

test_trials = 90
features = np.zeros([5, test_trials, 6])
y_hat = np.zeros([5, test_trials], dtype=int)


for fi in range(5):
    for ti in range(test_trials):
        features[fi][ti] = func_CSP(tmp[ti], W[fi], 3)

tmp_svc = []
for fi in range(5):
    svc = SVC(C=1, kernel='rbf', probability=True).fit(features[fi], label)
    tmp_svc.append(svc)
    y_hat[fi] = svc.predict(features[fi])
    print(svc.score(features[fi], label))

np.save('C:/Users/DELL/Desktop/competition/mi_debug/model.npy', [W, tmp_svc])
# mod = np.load('C:/Users/DELL/Desktop/competition/6.21/Algorithm/model/model0.npy', allow_pickle=True)

#%%
acc = []
for i in range(test_trials):
    acc.append(np.argmax(np.bincount(y_hat[:,i])))

corr = 0
for i in range(test_trials):
    if acc[i] == label[i]:
        corr += 1
print(corr/test_trials)
print(acc)


#%%



# import matplotlib.pyplot as plt
# plt.figure()
# x = np.linspace(1, 60, 60)
# plt.title('eigenvector CSP')
# plt.xlabel('Trials')
# for i in range(1,61):
#     plt.axvline(i)
# # plt.scatter(x,y_hat[0],label='W1',marker='^', alpha=0.9)
# # plt.scatter(x,y_hat[1],label='W2',marker='D', alpha=0.9)
# # plt.scatter(x,y_hat[2],label='W3',marker='*', alpha=0.9)
# # plt.scatter(x,y_hat[3],label='W4',marker='v', alpha=0.9)
# # plt.scatter(x,y_hat[4],label='W5',marker='+', alpha=0.9)
# plt.scatter(x,label,label='label',marker='d', alpha=0.9)
# plt.scatter(x,acc,label='W1',marker='^', alpha=0.9)
# plt.legend()
# plt.grid()
# plt.xlim(-5,62)
# plt.show()

#%%



# features = np.zeros([len(X), 6])
# for i in range(len(X)):
    
#     features[i] = func_CSP(X[i], W, 3)


# cv = ShuffleSplit(n_splits=10, test_size=0.2, random_state=7)
# clf = make_pipeline(
#     SVC(C=1, kernel='rbf')
#     )

# scores = cross_val_multiscore(estimator=clf,X=features,y=y,cv=cv,scoring='accuracy')

# mean = round(np.mean(scores),3)
# print(mean)
















