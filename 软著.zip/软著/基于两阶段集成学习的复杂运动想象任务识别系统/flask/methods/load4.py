# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 19:30:21 2022

@author: liurh
"""
import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from scipy import signal
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

#%%
# CSP

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

t = [500, 700]
f_low, f_high = 8, 30
rs = 13

def load(sub=1):

    f1 = open(f'./train/S0{sub}/Train/block_1.pkl','rb+')
    f2 = open(f'./train/S0{sub}/Train/block_2.pkl','rb+')
    f3 = open(f'./train/S0{sub}/Train/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names


def concat():
    data = []
    label = []

    for i in range(1, 6):
        tmp_data = load(i)
        data.append(tmp_data[0])
        label.append(tmp_data[1])
    return data, label

# 特征提取
def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features


# 滤波
def band_Filter(data):
    nyquist = 250 / 2
    frange = [f_low, f_high]
    b, a = signal.butter(4, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data


#%%

#  加载
data, label = concat()
n_sub = len(data)
n_trials = data[0].shape[0]

for si in range(n_sub):
    for ti in range(n_trials):
        data[si][ti] = band_Filter(data[si][ti])


# ---------------------
params = {'test_size': 0.3, 'random_state': rs, 'shuffle': True}
data_train = []
label_train = []
data_test = []
label_test = []

for si in range(n_sub):
    x_train, x_test, y_train, y_test = train_test_split(data[si], label[si], **params)
    data_train.append(x_train)
    label_train.append(y_train)
    data_test.append(x_test)
    label_test.append(y_test)
# ---------------------


# 训练
W = []
for si in range(n_sub):
    csp = CSP(n_components=15, reg='diagonal_fixed', norm_trace=False)
    W.append(csp.fit(data_train[si], label_train[si]).filters_)


train_trials = data_train[0].shape[0]
features = np.zeros([n_sub, train_trials, 6])
y_hat = np.zeros([n_sub, train_trials], dtype=int)
# train_trials = 63


# feature extraction
for si in range(n_sub):
    for ti in range(train_trials):
        features[si][ti] = func_CSP(data_train[si][ti], W[si], 3)


# classifer
tmp_svc = []
for si in range(n_sub):
    lda = LinearDiscriminantAnalysis().fit(features[si], label_train[si])
    # svc = SVC(C=1, kernel='rbf', probability=True).fit(features[si], label_train[si])
    tmp_svc.append(lda)
    y_hat[si] = lda.predict(features[si])
    print(lda.score(features[si], label_train[si]))

# ----------------------------

# test
print('\n 测试集:')
test_trials = 27
features = np.zeros([n_sub, test_trials, 6])

for si in range(n_sub):
    for ti in range(test_trials):
        features[si][ti] = func_CSP(data_test[si][ti], W[si], 3)

for si in range(n_sub):
    # y_hat[si] = tmp_svc[0].predict(features[si])
    print(tmp_svc[0].score(features[si], label_test[si]))

for i in range(5):
    np.save(f'C:/Users/DELL/Desktop/competition/mi_debug/model-{i+1}.npy', [W[i], tmp_svc[i]])

    
    
    








