# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 09:25:38 2022

@author: liurh
"""

from load_copy import export_bag

export_bag(1, [1, 3], [10, 13])


