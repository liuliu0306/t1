# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 10:23:23 2022

@author: DELL
"""

from shipincopy import use

a = use(1, [400, 500], [4, 30])