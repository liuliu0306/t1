# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 10:23:11 2022

@author: DELL
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 15:46:53 2022

@author: liurh
"""
import os
import inspect
import _pickle
import numpy as np
import mne
from mne.time_frequency import tfr_morlet
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from scipy import signal
import scipy
import scipy.fftpack
import matplotlib
import matplotlib.pyplot as plt
from IPython.core.pylabtools import figsize
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression

mne.set_log_level('warning')

import methods.tools as tools
# import tools

def use(sub=1, time=[], frequency=[]):
    print(time)
    print(frequency)
    filename = inspect.getframeinfo(inspect.currentframe()).filename
    path = os.path.dirname(os.path.abspath(filename))
    os.chdir(path)
    t = time
    f_low, f_high = frequency[0], frequency[1]
    epochs = tools.to_epoch(*tools.load(sub, t))

    n_trials, n_channels, n_timepoints = epochs.get_data().shape


    sfreq = epochs.info['sfreq']
    
    timevec = epochs.times
    trials = epochs.__len__()
    data_c3 = epochs.get_data(picks=['C3'])
    data_c4 = epochs.get_data(picks=['C4'])
    data_cz = epochs.get_data(picks=['Cz'])
    print(data_c3.shape)
    y = epochs.events[:,2]-201
    nfrex = 20
    def get_waves(nfrex=100):
        # create complex Morlet wavelets
        nfrex = nfrex
        frex  = np.linspace(f_low,f_high,nfrex)
        fwhm  = .5 # full-width at half-maximum in seconds
        
        # time vector for wavelets
        wavetime = np.arange(-2,2,1/sfreq)
            
        # initialize matrices for wavelets
        wavelets = np.zeros( (nfrex,len(wavetime)) ,dtype=complex)
        
        # create complex Morlet wavelet family
        for wi in range(0,nfrex):
            # Gaussian
            gaussian = np.exp( -(4*np.log(2)*wavetime**2) / fwhm**2 )
            
            # complex Morlet wavelet
            wavelets[wi,:] = np.exp(1j*2*np.pi*frex[wi]*wavetime) * gaussian
        return wavelets, wavetime, frex


    wavelets, wavetime, frex = get_waves(nfrex)
    def time_frequency_analysis(data,wavelets):
        
        nconv = len(timevec) + len(wavetime) - 1 # M+N-1
        halfk = int( np.floor(len(wavetime)/2) )
        dataX = scipy.fftpack.fft(data,nconv)  # Fourier spectrum of the signal
        tf = np.zeros( (nfrex,len(timevec)) )  # initialize time-frequency matrix
        tfN = np.zeros( (nfrex,len(timevec)) )
        basepow     = np.zeros(nfrex)
      
        # convolution per frequency
        for fi in range(0,nfrex):
            # FFT of the wavelet
            waveX = scipy.fftpack.fft(wavelets[fi,:],nconv)
            # amplitude-normalize the wavelet
            waveX = waveX/np.max(waveX)
            convres = scipy.fftpack.ifft( waveX*dataX )
            convres = convres[halfk-1:-halfk]  # trim the "wings"
            tf[fi,:] = np.abs(convres)**2  # extract power from complex signal
            basepow[fi] = np.mean(tf[fi,:])
            tfN[fi,:] = tf[fi,:]/basepow[fi]
        return tf
    tf = time_frequency_analysis(data_c3, wavelets)
    return tf

    
    
# t = [500, 1500]
# f_low, f_high = 8, 30
# rs = 12587
# sub = 1

# epochs = tools.to_epoch(*tools.load(sub, t))

# n_trials, n_channels, n_timepoints = epochs.get_data().shape


# sfreq = epochs.info['sfreq']
# timevec = epochs.times
# trials = epochs.__len__()
# data_c3 = epochs.get_data(picks=['C3'])
# data_c4 = epochs.get_data(picks=['C4'])
# data_cz = epochs.get_data(picks=['Cz'])

# y = epochs.events[:,2]-201
# nfrex = 100
# def get_waves(nfrex=100):
#     # create complex Morlet wavelets
#     nfrex = nfrex
#     frex  = np.linspace(8,15,nfrex)
#     fwhm  = .5 # full-width at half-maximum in seconds
    
#     # time vector for wavelets
#     wavetime = np.arange(-2,2,1/sfreq)
        
#     # initialize matrices for wavelets
#     wavelets = np.zeros( (nfrex,len(wavetime)) ,dtype=complex)
    
#     # create complex Morlet wavelet family
#     for wi in range(0,nfrex):
#         # Gaussian
#         gaussian = np.exp( -(4*np.log(2)*wavetime**2) / fwhm**2 )
        
#         # complex Morlet wavelet
#         wavelets[wi,:] = np.exp(1j*2*np.pi*frex[wi]*wavetime) * gaussian
#     return wavelets, wavetime, frex


# wavelets, wavetime, frex = get_waves(nfrex)

# def time_frequency_analysis(data,wavelets):
    
#     nconv = len(timevec) + len(wavetime) - 1 # M+N-1
#     halfk = int( np.floor(len(wavetime)/2) )
#     dataX = scipy.fftpack.fft(data,nconv)  # Fourier spectrum of the signal
#     tf = np.zeros( (nfrex,len(timevec)) )  # initialize time-frequency matrix
#     tfN = np.zeros( (nfrex,len(timevec)) )
#     basepow     = np.zeros(nfrex)
  
#     # convolution per frequency
#     for fi in range(0,nfrex):
#         # FFT of the wavelet
#         waveX = scipy.fftpack.fft(wavelets[fi,:],nconv)
#         # amplitude-normalize the wavelet
#         waveX = waveX/np.max(waveX)
#         convres = scipy.fftpack.ifft( waveX*dataX )
#         convres = convres[halfk-1:-halfk]  # trim the "wings"
#         tf[fi,:] = np.abs(convres)**2  # extract power from complex signal
#         basepow[fi] = np.mean(tf[fi,:])
#         tfN[fi,:] = tf[fi,:]/basepow[fi]
#     return tf
    # return tfN
    

    
# def showd(i):
#     # different scale
#     tf3 = time_frequency_analysis(data_c3[i-1][0],wavelets)
#     tf4 = time_frequency_analysis(data_c4[i-1][0],wavelets)
    
#     plt.figure()
  
#     vmax = np.max([np.max(tf3),np.max(tf4)])/1.2
#     plt.subplot(221)
#     # plt.pcolormesh(timevec,frex,tf3,vmin=0,vmax=np.max([np.max(tf4),np.max(tf3)])/1.2)
#     plt.pcolormesh(timevec,frex,tf3,vmin=0,vmax=np.max(np.max(tf3))/1.2) 
#     plt.title('NO.{} , event = {} , C3;different scale'.format(i,'left' if y[i-1]==0 else 'right'))   
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    
#     plt.subplot(222)
#     # plt.pcolormesh(timevec,frex,tf4,vmin=0,vmax=np.max([np.max(tf4),np.max(tf3)])/1.2)
#     plt.pcolormesh(timevec,frex,tf4,vmin=0,vmax=np.max(np.max(tf4))/1.2) 
#     plt.title('NO.{} , event = {} , C4;different scale'.format(i,'left' if y[i-1]==0 else 'right'))
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    
#     vmax = np.max([np.max(tf3),np.max(tf4)])/1.2
#     plt.subplot(223)
#     plt.pcolormesh(timevec,frex,tf3,vmin=0,vmax=vmax) 
#     plt.title('NO.{} , event = {} , C3;same scale'.format(i,'left' if y[i-1]==0 else 'right'))   
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    
#     plt.subplot(224)
#     plt.pcolormesh(timevec,frex,tf4,vmin=0,vmax=vmax)
#     plt.title('NO.{} , event = {} , C4;same scale'.format(i,'left' if y[i-1]==0 else 'right'))
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    
#     plt.show()
    


# def save(i):
     
#     tf3 = time_frequency_analysis(data_c3[i-1][0],wavelets)
#     tf4 = time_frequency_analysis(data_c4[i-1][0],wavelets)
    
#     # 保存图片但不显示
#     matplotlib.use('Agg')
#     plt.figure()
    
    
#     vmax = np.max([np.max(tf3),np.max(tf4)])/1.2
#     # same scale
    
#     figsize(28,12)
#     plt.subplot(121)
#     plt.pcolormesh(timevec,frex,tf3,vmin=0,vmax=vmax)
#     plt.title('NO.{} , event = {} , C3'.format(i,'left' if y[i-1]==0 else 'right'),fontsize=18)   
#     plt.xlabel('Time (s)',fontsize=16), plt.ylabel('Frequency (Hz)',fontsize=16)
    
#     plt.subplot(122)
#     plt.pcolormesh(timevec,frex,tf4,vmin=0,vmax=vmax)
#     plt.title('NO.{} , event = {} , C4'.format(i,'left' if y[i-1]==0 else 'right'),fontsize=18)
#     plt.xlabel('Time (s)',fontsize=16), plt.ylabel('Frequency (Hz)',fontsize=16)  
    
#     plt.savefig('D:/tfm/{}.jpg'.format(i))

# for i in range(120):
#     save(i+1)
#     print('NO.{} is ok!'.format(i+1))


# def show(i):   
#     # show in same scale
    
#     tf3 = time_frequency_analysis(data_c3[i-1][0],wavelets)
#     tf4 = time_frequency_analysis(data_c4[i-1][0],wavelets)
#     tf5 = time_frequency_analysis(data_cz[i-1][0],wavelets)
  
#     plt.figure()
  
#     vmax = np.max([np.max(tf3[:,250:]),np.max(tf4[:,250:])])/1.2

#     plt.subplot(131)
#     plt.pcolormesh(timevec[250:],frex,tf3[:,250:],vmin=0,vmax=vmax,shading='auto')
#     plt.title('NO.{} , event = {} , C3'.format(i,'left' if y[i-1]==0 else 'right'))   
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    
#     plt.subplot(132)
#     plt.pcolormesh(timevec[250:],frex,tf4[:,250:],vmin=0,vmax=vmax,shading='auto')
#     plt.title('NO.{} , event = {} , C4'.format(i,'left' if y[i-1]==0 else 'right'))
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')  
#     plt.show()

#     plt.subplot(133)
#     plt.pcolormesh(timevec[250:],frex,tf5[:,250:],vmin=0,vmax=vmax,shading='auto')
#     plt.title('NO.{} , event = {} , C4'.format(i,'left' if y[i-1]==0 else 'right'))
#     plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')  
#     plt.show()