# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 09:27:59 2022

@author: liurh
"""
import numpy as np
import os
import inspect
import _pickle
import mne

mne.set_log_level('warning')
path = 'C:/Users/DELL/Desktop/test'
os.chdir(path)
import CSPSVMClass


def load(sub=1):

    f1 = open(f'./test_data/S0{sub}/block_1.pkl','rb+')
    f2 = open(f'./test_data/S0{sub}/block_2.pkl','rb+')
    f3 = open(f'./test_data/S0{sub}/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data, label, ch_names

def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features


for sub in range(1, 6):

    epoch_data, label, ch_names = load(sub)
    csp_class = CSPSVMClass.CSPSVMClass()
    res = []
    for i in range(len(epoch_data)):
        tmp = csp_class.recognize(epoch_data[i,:,500:1000], sub)
        res.append(tmp)

    corr = 0
    for i in range(len(epoch_data)):
        if res[i] == label[i]:
            corr += 1
    print(corr/len(epoch_data))
    # print(res)

# np.where(np.array(res)==201)[0].shape

# sub = 1
# epoch_data, label, ch_names = load(sub)
# csp_class = CSPSVMClass.CSPSVMClass()
# res = []
# for i in range(len(epoch_data)):
#     tmp = csp_class.recognize(epoch_data[i,:,500:1000], sub)
#     res.append(tmp)

# corr = 0
# for i in range(len(epoch_data)):
#     if res[i] == label[i]:
#         corr += 1
# print(corr/len(epoch_data))

