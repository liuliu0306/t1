# -*- coding: utf-8 -*-
"""
Created on Sun May  8 15:29:06 2022

@author: liurh
"""
import numpy as np
import torch
import mne
import _pickle
from scipy.signal import hilbert
# from torch_geometric.data import Data
import matplotlib.pyplot as plt
import sklearn.metrics as skm
from mne.decoding import PSDEstimator
from sklearn.preprocessing import StandardScaler
from scipy import signal
from mne.channels import make_dig_montage
from methods.montage_dict import montagePosition
# import pandas as pd
# import seaborn as sns
from sklearn.manifold import TSNE

mne.set_log_level('warning')

def get_degree(A):
    A = binary(A)
    return torch.sum(A,axis=1)

def psd(data, sfreq=200, fmin=8, fmax=30):
    PSD = PSDEstimator(sfreq, fmin, fmax)
    psd_data = PSD.transform(data)
    psd_data = np.mean(psd_data, 2)
    psd_data = StandardScaler().fit_transform(psd_data)

    return torch.from_numpy(psd_data)

def DE(data, sfreq=200, fmin=8, fmax=30):
    PSD = PSDEstimator(sfreq, fmin, fmax)
    psd_data = PSD.transform(data)
    tensor = torch.from_numpy(psd_data)
    tmp = torch.log2(tensor)
    return torch.mean(tmp, 2)


def info(graph):
    print(f'Nodes: {graph.num_nodes}')
    print(f'Edges: {graph.num_edges}')
    print(f'Node features: {graph.num_node_features}')
    print(f'Graph directed: {graph.is_directed()}')
    
    
def get_brian_network(data, type='plv'):
    # compute phase synchronization between each pair
    # data = n_channels, n_timepoints
    ang = np.angle(hilbert(data))
    n_channels = len(data)
    connect_mat = np.zeros([n_channels,n_channels])
    for i in range(n_channels):
        for j in range(i,n_channels):
            
            euler = np.exp(1j*(ang[i]-ang[j]))

            if type == 'plv':
                cnt = np.abs( np.mean(euler) )
            elif type == 'pli':
                cnt = np.abs(np.mean(np.sign( np.imag(euler) )))
            elif type == 'pcc':
                connect_mat = np.corrcoef(data)
                return connect_mat
            connect_mat[i,j] = np.mean(cnt)
            connect_mat[j,i] = connect_mat[i,j]
    return connect_mat


def extension(data, label):
    # data.shape = (n_trials, n_channels, n_timepoints)
    free = data[np.where(label==1)[0]]
    free = np.rollaxis(free, 1, 0)
    free_long = np.reshape(free, [ free.shape[0],free.shape[1]*free.shape[2] ])
    
    data_move = np.delete(data, np.where(label==1)[0], 0)
    data_free = np.zeros([249, 62, 400])
    for i in range(249):
        data_free[i] = free_long[:,200*i:200*(i+1)+200]
    
    tmp = np.vstack([data_move, data_free])  
    label = np.zeros(499)
    label[250:] = 1

    return tmp, label

def plot(connect_mat):
    # low,high = np.min(connect_mat),np.mean(connect_mat)*2
    low,high = 0, 1
    clim = [low,high]

    plt.figure()
    plt.subplot(111,aspect='equal')
    plt.pcolormesh(connect_mat)
    plt.clim(clim[0],clim[1])
    # plt.colorbar(orientation='horizontal')
    plt.xlabel('Channels'), plt.ylabel('Channels')
    
    plt.show()

def binary(A, critical=.5):
# Binarize Adjacency Matrix
    A_binary = torch.empty(A.shape)
    A_binary[A >= critical] = 1
    A_binary[A < critical] = 0
    return A_binary

def graph_data(A, x, y=None):
    """
    Input: A -> Adjacency matrix;
           x -> Node features, [n_nodes, n_features]
    Output: Geometric graph
    """

    if len(x) != len(A):
        return None

    if y is None:
        y = torch.tensor([[1]]).long()
    else:
        y = torch.tensor([y]).long()

    row, col = torch.where(A != 0)
    x = x.float()

    edge_index = torch.vstack([ row, col]).long()
    edge_attr = A[row, col][:,None]

    # graph = Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=y)

    # return graph

def load(sub=1, t=[8, 30]):

    f1 = open(f'../train/S0{sub}/block_1.pkl','rb+')
    f2 = open(f'../train/S0{sub}/block_2.pkl','rb+')
    f3 = open(f'../train/S0{sub}/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names


# 特征提取
def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features





def tSNE(x_tsne, y_train):
    tsne = TSNE(n_components=2)
    x_tsne = tsne.fit_transform(x_tsne)
    # plot_xy(x_tsne, y_train.astype(int), "t-sne")
 
# 滤波
def band_Filter(data, f_low, f_high):
    nyquist = 125
    frange = [f_low, f_high]
    b, a = signal.butter(4, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data

def to_epoch(data, label, ch_names):
    montage_dict = montagePosition.getMontagePosition()
    make_dig_montage_param = dict(
    ch_pos=montage_dict,
    nasion=[0.1123,88.2470,-1.7130],
    lpa=[-84.8302,-46.0217,-7.0560],
    rpa=[85.5488,-45.5453,-7.1300]
    )
    montage = make_dig_montage(**make_dig_montage_param)
    
    srate = 250
    length = len(data)
    events = np.zeros([length, 3], dtype=int)
    event_id = {'hand/left':201,'hand/right':202,'foot':203}

    for ti in range(length):
        events[ti] = np.array([2000*ti, 0, label[ti]])

    info = mne.create_info(ch_names, srate, ch_types='eeg')
    epochs = mne.EpochsArray(data, info, events, event_id=event_id)
    epochs.set_montage(montage)
    return epochs

def kld(mu, sigma):
    # Compute Kullback-Leibler divergence
    tmp1 = torch.pow(mu, 2) + torch.pow(sigma, 2)
    tmp2 = torch.log(1e-8 + torch.pow(sigma, 2))
    kld = torch.sum(tmp1-tmp2-1) * 0.5
    return kld


def plot_pro(Acc_tr, Acc_te, loss):

    N = len(Acc_tr)
    x = np.linspace(1,N,N)
    plt.figure()
    plt.subplot(122)
    plt.plot(x, Acc_tr,'o-',label='train accuracy')
    plt.plot(x, Acc_te,'s-',label='test accuracy')
    
    plt.xlabel('Epochs'), plt.ylabel('Accuracy')
    tr, te = max(Acc_tr), max(Acc_te)
    plt.title(f'two targets max={tr:.2f}/{te:.2f}')
    plt.legend()
    plt.grid()
    
    
    plt.subplot(121)
    plt.plot(x, loss,'o-')
    plt.xlabel('Epochs'), plt.ylabel('loss')
    plt.title('loss')
    plt.grid()
    plt.show()

def plot_cm(d, y_hat):
    y_hat = y_hat.argmax(dim=1)
    trainConf = skm.confusion_matrix(d.y.numpy(), y_hat.numpy())
    # confmat during TRAIN
    plt.figure()
    plt.imshow(trainConf,'Blues',vmax=len(y_hat)//2)
    plt.xticks([0,1])
    plt.yticks([0,1])
    
    acc = np.trace(trainConf)/np.sum(trainConf)
    plt.xlabel('Predicted quality')
    plt.ylabel('True quality')
    plt.title(f'Last predict, trials=499, acc={acc:.2f}%')
    
    # add text labels
    plt.text(0,0,f'True:\n{trainConf[0,0]}' ,ha='center',va='center')
    plt.text(1,0,f'False:\n{trainConf[0,1]}',ha='center',va='center')
    
    plt.text(0,1,f'False:\n{trainConf[1,0]}',ha='center',va='center')
    plt.text(1,1,f'True:\n{trainConf[1,1]}' ,ha='center',va='center')

#%%
# for test
"""
data = torch.rand([10,3,3])

data_binary = binary(data)
x = torch.tensor([[1],[1],[1]])

graph = graph_data(data_binary[0], x, 2)

info(graph)

data_list = [graph_data(d,x) for d in data_binary]

dataset = DataLoader(data_list, batch_size=1)

"""

