# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 16:00:42 2022

@author: liurh
"""
import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP
from scipy import signal
from sklearn.model_selection import train_test_split
from sklearn.metrics import mutual_info_score

def warn(*args, **kwargs):
    pass
import warnings
warnings.warn = warn


mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

t = [500, 1000]
k = 30
sub = 5
# f_low, f_high = 10, 14

def load(sub=1):

    f1 = open(f'./train/S0{sub}/Train/block_1.pkl','rb+')
    f2 = open(f'./train/S0{sub}/Train/block_2.pkl','rb+')
    f3 = open(f'./train/S0{sub}/Train/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names

def concat():
    data = []
    label = []

    for i in range(1, 6):
        tmp_data = load(i)
        data.append(tmp_data[0])
        label.append(tmp_data[1])
    return data, label


def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features

def band_Filter(data, f_low, f_high):
    nyquist = 125
    frange = [f_low, f_high]
    b, a = signal.butter(5, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data

def fuse(features, label, k=10):
    res = np.zeros([ features.shape[1], k ])
    mi = np.zeros(features.shape[1])
    for i in range(features.shape[1]):

        mi[i] = mutual_info_score(features[:, i], label)
    sort_mi = np.argsort(mi)

    tmp = features[:,sort_mi]
    res = tmp[:, -k:]
    return res, sort_mi


data, label, _ = load(sub)

n_bands = 8
n_trials = data.shape[0]
n_channels = data.shape[1]
n_timepoints = data.shape[2]

freq_start = np.linspace(4, 32, n_bands, dtype=int)
freq_end = freq_start + 4
freq = np.array([freq_start, freq_end])


train_trials = 63
test_trials = 27
data_f = np.zeros([ n_bands, train_trials, n_channels, n_timepoints ])
data_test = np.zeros([ n_bands, test_trials, n_channels, n_timepoints ])

params = {'test_size': 0.3, 'random_state': 5, 'shuffle': True}

x_train, x_test, y_train, y_test = train_test_split(data, label, **params)


for fi in range(n_bands):
    for ti in range(train_trials):
        data_f[fi][ti] = band_Filter(x_train[ti], freq[0, fi], freq[1, fi])

for fi in range(n_bands):
    for ti in range(test_trials):
        data_test[fi][ti] = band_Filter(x_test[ti], freq[0, fi], freq[1, fi])


features = np.zeros([ train_trials, 6*n_bands ])  # 63:训练集trial数

W_bands = []
for fi in range(n_bands):

    csp = CSP(n_components=15, reg='diagonal_fixed', norm_trace=False)
    W_bands.append(csp.fit(data_f[fi], y_train).filters_)

    y_hat = np.zeros([5, train_trials], dtype=int)

    # feature extraction
    for ti in range(train_trials):
        features[ti][fi*6: (fi+1)*6] = func_CSP(data_f[fi][ti], W_bands[fi], 3)


# fuse
features_fuse, sort_mi = fuse(features, y_train, k)
# shape=[n_sub, n_trials, k]

# classifer
tmp_svc = []
svc = SVC(C=1, kernel='rbf', probability=True).fit(features_fuse, y_train)
tmp_svc.append(svc)
# y_hat = svc.predict(features_fuse[si])
print(svc.score(features_fuse, y_train))


# test

# data_filtered = np.zeros([ n_bands, test_trials, n_channels, n_timepoints ])


# for fi in range(n_bands):
#     for ti in range(test_trials):
#         data_filtered[fi][ti] = band_Filter(data_test[fi][ti], freq[0, fi], freq[1, fi])


test_feature = np.zeros([ test_trials, 6*n_bands ])
test_trials = test_feature.shape[0]
# stage1: 特征提取
for fi in range(n_bands):
    for ti in range(test_trials):
        test_feature[ti][fi*6: (fi+1)*6] = func_CSP(data_test[fi][ti], W_bands[fi], 3)

features_test_fuse = test_feature[:, sort_mi][:, -k:]
# shape=[n_trials, k]

y_hat = np.zeros([test_trials], dtype=int)
# classifer
print('\n测试集:')
y_hat = tmp_svc[0].predict(features_test_fuse)
print(tmp_svc[0].score(features_test_fuse, y_test))   







