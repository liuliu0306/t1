# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 15:43:22 2022

@author: liurh
"""


import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from scipy import signal
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression

from sklearn.preprocessing import StandardScaler

# CSP

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)
import tools
from laplacian_raw import surface_laplacian
from montage_dict import montagePosition


t = [250, 600]
f_low, f_high = 8, 30
rs = 2
sub = 1



def load(sub=1):

    f1 = open(f'./train/S0{sub}/Train/block_1.pkl','rb+')
    f2 = open(f'./train/S0{sub}/Train/block_2.pkl','rb+')
    f3 = open(f'./train/S0{sub}/Train/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names

def extension(data, label):
    # data.shape = (n_trials, n_channels, n_timepoints)
    class1 = data[np.where(label==201)[0]]
    class2 = data[np.where(label==202)[0]]
    class1 = np.rollaxis(class1, 1, 0)
    class2 = np.rollaxis(class2, 1, 0)
    _long1 = np.reshape(class1, [ class1.shape[0],class1.shape[1]*class1.shape[2] ])
    _long2 = np.reshape(class2, [ class2.shape[0],class2.shape[1]*class2.shape[2] ])
    _len = class1.shape[2]
    helf_len = _len//2

    # data_move = np.delete(data, np.where(label==203)[0], 0)
    data_class1 = np.zeros([59, data.shape[1], _len])
    data_class2 = np.zeros([59, data.shape[1], _len])
    
    for i in range(data.shape[1]):
        data_class1[i] = _long1[:,helf_len*i:helf_len*(i+1)+helf_len]
        data_class2[i] = _long2[:,helf_len*i:helf_len*(i+1)+helf_len]
        
    tmp = np.vstack([data_class1, data_class2])  
    label = np.zeros(len(tmp))+201
    label[59:] = 202

    return tmp, label

# 特征提取
def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features


# 滤波
def band_Filter(data):
    nyquist = 125
    frange = [f_low, f_high]
    b, a = signal.butter(4, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data

data, label, ch_names = load(sub)
# for ti in range(90):
#     data[ti] = StandardScaler().fit_transform(data[ti])
    
# montage_dict = montagePosition.getMontagePosition()
# location = np.array(list(montage_dict.values()))
# data_laplacian = surface_laplacian(np.rollaxis(data, 0, 3),location[:,0],location[:,1],location[:,2],m=2,leg_order=50,smoothing=1e-5)
# data_laplacian = np.rollaxis(data_laplacian, 2, 0)
# data = data_laplacian

epochs = tools.to_epoch(data, label, ch_names).filter(8,30,method='iir')
data = epochs.get_data(tmin=1)
#%%
import matplotlib.pyplot as plt
epochs.plot(n_epochs=10, events=epochs.events, picks=['C3','C4'], scalings=10)
# epochs[0].plot(events=epochs.events, picks=['Fpz','AF3'])

# epochs.plot_image()
"""
# data = np.mean(data, 0)
trial = 10
plt.figure()
plt.plot(data[25],label='Cz', alpha=1)
plt.plot(data[28],label='C3', alpha=0.65)
plt.plot(data[29],label='C4', alpha=0.6)
# plt.plot(data[trial][25],label='Cz', alpha=1)
# plt.plot(data[trial][28],label='C3', alpha=0.65)
# plt.plot(data[trial][29],label='C4', alpha=0.6)

# plt.plot(data[trial][4], alpha=0.2)
# plt.plot(data[trial][5], alpha=0.2)
# plt.plot(data[trial][6], alpha=0.2)
# plt.plot(data[trial][7], alpha=0.2)
# plt.plot(data[trial][8], alpha=0.2)
plt.legend(loc=1)
plt.show()
"""

#%%
n_trials = data.shape[0]
n_channels = data.shape[1]
n_timepoints = data.shape[2]
for ti in range(n_trials):
    data[ti] = band_Filter(data[ti])


foot_label = np.where(label == 203)[0]
data_hands = np.delete(data, foot_label, 0)
label_hands = np.delete(label, foot_label)

e_data, e_label = extension(data, label)


# ---------------------
params = {'test_size': 0.3, 'random_state': rs, 'shuffle': True}


x_train, x_test, y_train, y_test = train_test_split(e_data, e_label, **params)

# ---------------------
# 训练
W = []

csp = CSP(n_components=15, reg='diagonal_fixed', norm_trace=False)
W.append(csp.fit(x_train, y_train).filters_)

train_trials = x_train.shape[0]
features = np.zeros([train_trials, 6])
y_hat = np.zeros([train_trials], dtype=int)
# train_trials = 63

# feature extraction

for ti in range(train_trials):
    features[ti] = func_CSP(x_train[ti], W[0], 3)



# classifer
tmp_svc = []

# mode = LogisticRegression(random_state=3).fit(features, y_train)
# mode = LinearDiscriminantAnalysis().fit(features, y_train)
# mode = SVC(C=1, kernel='rbf', probability=True).fit(features, y_train)
mode1 = LogisticRegression(random_state=3).fit(features, y_train)
mode2 = LinearDiscriminantAnalysis().fit(features, y_train)
mode3 = SVC(C=1, kernel='rbf', probability=True).fit(features, y_train)
# tmp_svc.append(mode)
# y_hat = tmp_svc[0].predict(features)
print('Logistic: ', mode1.score(features, y_train))
print('LDA:      ', mode2.score(features, y_train))
print('SVM:      ', mode3.score(features, y_train))
# tmp_svc.append(mode)
# y_hat = tmp_svc[0].predict(features)
# print(tmp_svc[0].score(features, y_train))

# ----------------------------

# test
print('\n 测试集:')
test_trials = len(y_test)
features = np.zeros([test_trials, 6])

for ti in range(test_trials):
    features[ti] = func_CSP(x_test[ti], W[0], 3)

tools.tSNE(features, y_test)
# y_hat = tmp_svc[0].predict(features)
print('Logistic: ', mode1.score(features, y_test))
print('LDA:      ', mode2.score(features, y_test))
print('SVM:      ', mode3.score(features, y_test))
# for i in range(5):
#     np.save(f'C:/Users/DELL/Desktop/competition/mi_debug/model-{i+1}.npy', [W[i], tmp_svc[i]])


from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression


features = StandardScaler().fit_transform(features)
cv = ShuffleSplit(n_splits=10, test_size=0.3, random_state=7)
clf = make_pipeline(
    # LogisticRegression()
    SVC(C=1, kernel='rbf')
    )
scores = cross_val_multiscore(estimator=clf,X=features,y=y_test,cv=cv,scoring='accuracy')

mean = round(np.mean(scores),3)
print(mean)
    










