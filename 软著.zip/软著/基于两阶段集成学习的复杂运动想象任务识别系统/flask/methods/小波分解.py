# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 10:12:51 2022

@author: liurh
"""
import os
import inspect
import _pickle
import numpy as np
import mne

# import scipy
import sys
from scipy.fftpack import fft, ifft
import matplotlib.pyplot as plt
from IPython.core.pylabtools import figsize
import matplotlib

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)
import tools
from laplacian_raw import surface_laplacian


t = [500, 1500]
f_low, f_high = 8, 30
sub = 1


# epochs = tools.to_epoch(*tools.load(sub, t)).filter(f_low, f_high,method='iir')

epochs = tools.to_epoch(*tools.load(sub, t))
data = epochs.get_data()
for i in range(90):
    data[i] = tools.band_Filter(data[i], f_low, f_high)
label = epochs.events[:,2]-201
timevec = epochs.times
trials = epochs.__len__()
morlet = [f_low, f_high, 50]

# epochs.get_montage().plot()
pos = epochs.get_montage().get_positions()['ch_pos']
location = np.array(list(pos.values()))
data_laplacian = surface_laplacian(np.rollaxis(data, 0, 3),location[:,0],location[:,1],location[:,2],m=2,leg_order=50,smoothing=1e-5)
data_laplacian = np.rollaxis(data_laplacian, 2, 0)

n_trials, n_channels, n_timepoints = epochs.get_data().shape


def morlet_family(minFreq=8, maxFreq=20, numFrex=30):
    # srate = maxFreq*2
    frex  = np.linspace(minFreq,maxFreq,numFrex)
    fwhms = np.linspace(0.4, 0.5, numFrex)
    wavetime = np.arange(-2, 2, 1/250)
    wavelets = np.zeros( (numFrex,len(wavetime)) ,dtype=complex)
    
    # create complex Morlet wavelet family
    for wi in range(numFrex):
        gaussian = np.exp( -(4*np.log(2)*wavetime**2) / fwhms[wi]**2 )
        wavelets[wi,:] = np.exp(1j*2*np.pi*frex[wi]*wavetime) * gaussian

    return wavelets, wavetime

def show(i=0):   
    # show in same scale
    tf = time_frequency_analysis(data[i][26], wavelets)
    frex  = np.linspace(morlet[0], morlet[1], morlet[2])
    plt.figure()
    plt.pcolormesh(timevec,frex,tf,shading='auto')
    plt.title('trial = {}, events = {}'.format(i+1, label[i])) 
    plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    plt.show()

def show_3(i=0, laplacian=False):   
    # show in same scale
    figsize(18,5)
    if laplacian:
        tf1 = time_frequency_analysis(data_laplacian[i][28], wavelets)
        tf2 = time_frequency_analysis(data_laplacian[i][25], wavelets)
        tf3 = time_frequency_analysis(data_laplacian[i][29], wavelets)
    else:
        data = epochs[i].get_data(picks=['C3', 'Cz', 'C4'])
        tf1 = time_frequency_analysis(data[0][0], wavelets)
        tf2 = time_frequency_analysis(data[0][1], wavelets)
        tf3 = time_frequency_analysis(data[0][2], wavelets)
    
    vmax = np.max(np.concatenate([tf1, tf2, tf3]))/5
    frex  = np.linspace(morlet[0], morlet[1], morlet[2])
    plt.subplot(131)
    plt.pcolormesh(timevec,frex,tf1,shading='auto', vmax=vmax)
    plt.title('C3, trial = {}, events = {}'.format(i+1, label[i])) 
    # plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    plt.subplot(132)
    plt.pcolormesh(timevec,frex,tf2,shading='auto', vmax=vmax)
    plt.title('Cz, trial = {}, events = {}'.format(i+1, label[i])) 
    # plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')
    plt.subplot(133)
    plt.pcolormesh(timevec,frex,tf3,shading='auto', vmax=vmax)
    plt.title('C4, trial = {}, events = {}'.format(i+1, label[i])) 
    # plt.xlabel('Time (s)'), plt.ylabel('Frequency (Hz)')

def save(i):
    # 保存图片但不显示
    matplotlib.use('Agg')
    show_3(i)
    plt.savefig('D:/tfm/{}.jpg'.format(i))

def time_frequency_analysis(data, wavelets):
    numFrex = len(wavelets)
    wavetimes = len(wavelets.T)
    nconv = len(timevec) + wavetimes - 1 # M+N-1
    halfk = int( np.floor(wavetimes/2) )
    # tfN = np.zeros( (numFrex,len(timevec)) )
    # basepow     = np.zeros(numFrex)
    # Fourier spectrum of the signal
    dataX = fft(data,nconv)
    
    tf = np.zeros( (numFrex, len(timevec)) )

    for fi in range(numFrex):
        waveX = fft(wavelets[fi,:],nconv)
        waveX = waveX/np.max(waveX)
        convres = ifft( waveX*dataX )     
        convres = convres[halfk-1:-halfk]  # trim the "wings"
        tf[fi,:] = np.abs(convres)**2
        # basepow[fi] = np.mean(tf[fi,:])
        # tfN[fi,:] = tf[fi,:]/basepow[fi]
    return tf

wavelets, wavetime = morlet_family(*morlet)
#%%
for i in range(90):
    msg = f'Epochs {i+1}/{trials}'
    sys.stdout.write('\r' + msg)
    save(i)


"""
d = np.zeros([90, 150, 200])
for i in range(90):
    # data = epochs[i].get_data(picks=['C3', 'Cz', 'C4'])
    # tf1 = time_frequency_analysis(data[0][0], wavelets)
    # tf2 = time_frequency_analysis(data[0][1], wavelets)
    # tf3 = time_frequency_analysis(data[0][2], wavelets)

    tf1 = time_frequency_analysis(data_laplacian[i][28], wavelets)
    tf2 = time_frequency_analysis(data_laplacian[i][25], wavelets)
    tf3 = time_frequency_analysis(data_laplacian[i][29], wavelets)

    tmp = np.vstack([tf1, tf2, tf3])
    d[i] = tmp
    msg = f'Epochs {i+1}/{trials}'
    sys.stdout.write('\r' + msg)
np.save('C:/Users/DELL/Desktop/competition/mi_debug/use_2.npy', d)

"""
# a = np.vstack([tf1, tf2, tf3])
# plt.pcolormesh(a)

#%%
"""
# 特征提取
# 1.能量
data = epochs['left','right'].get_data(picks=['C3','C4'])
label = epochs['left','right'].events[:,2]-201
# data_laplacian = data_laplacian[:,28:30]
# data = data_laplacian
f1 = np.zeros([len(data), 1])
for i in range(len(data)):
    f1[i] = np.sum(data[i][0]**2) - np.sum(data[i][1]**2)

label[np.where(label==2)[0]] = 1

from mne.decoding import cross_val_multiscore
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import ShuffleSplit
from sklearn.pipeline import make_pipeline

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression

X = StandardScaler().fit_transform(f1.reshape(-1, 1))
cv = ShuffleSplit(n_splits=10, test_size=0.3, random_state=444)
clf = make_pipeline(
    LogisticRegression()
    # SVC(C=1, kernel='rbf')
    )
scores = cross_val_multiscore(estimator=clf,X=X,y=label,cv=cv,scoring='accuracy')

mean = round(np.mean(scores),3)
print(mean)
"""

"""
# 统计特征
# data = epochs.get_data(picks=['C3','Cz','C4'])
label = epochs.events[:,2]-201

data_laplacian = data_laplacian[:,[25,28,29]]
data = data_laplacian
f1 = np.zeros([len(data), 9])
for i in range(len(data)):
    f1[i][:3] = np.mean(data[i], 1)
    f1[i][3:6] = np.std(data[i], 1)
    f1[i][6:] = np.sqrt(np.std(data[i], 1))




from mne.decoding import cross_val_multiscore
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import ShuffleSplit
from sklearn.pipeline import make_pipeline

from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression


# f1 = StandardScaler().fit_transform(f1)
# svc = SVC(C=1, kernel='rbf', probability=True).fit(f1[:60], label[:60])
# y = svc.predict(f1[:10])
# print(svc.score(f1[60:], label[60:]))

# np.save(f'C:/Users/DELL/Desktop/competition/mi_debug/model-{sub}.npy', [svc])



# f1 = StandardScaler().fit_transform(f1)
cv = ShuffleSplit(n_splits=10, test_size=0.3, random_state=12)
clf = make_pipeline(
    # LogisticRegression()
    SVC(C=1, kernel='rbf')
    )
scores = cross_val_multiscore(estimator=clf,X=f1,y=label,cv=cv,scoring='accuracy')

mean = round(np.mean(scores),3)
print(mean)

"""























