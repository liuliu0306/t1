# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 15:43:22 2022

@author: liurh
"""


import os
import inspect
import _pickle
import numpy as np
import mne
from sklearn.svm import SVC
from mne.decoding import CSP,cross_val_multiscore

from scipy import signal
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression

# CSP

mne.set_log_level('warning')
filename = inspect.getframeinfo(inspect.currentframe()).filename
path = os.path.dirname(os.path.abspath(filename))
os.chdir(path)

t = [520, 620]
f_low, f_high = 8, 30
rs = 12587
sub = 5



def load(sub=1):

    f1 = open(f'./train/S0{sub}/Train/block_1.pkl','rb+')
    f2 = open(f'./train/S0{sub}/Train/block_2.pkl','rb+')
    f3 = open(f'./train/S0{sub}/Train/block_3.pkl','rb+')
    data1 = _pickle.load(f1)
    data2 = _pickle.load(f2)
    data3 = _pickle.load(f3)
    data = np.hstack([data1['data'], data2['data'], data3['data']])

    trigger = data[-1]
    data = data[:-6]
    
    ch_names = data1['ch_names'][:-5]
    nchan = len(data)
    srate = 250

    n_trials = 90

    n_timepoint = 8*srate

    epoch_data = np.zeros([n_trials, nchan, n_timepoint])
    trigger[np.where(trigger == 0)[0]] = 300
    label = trigger[np.where(trigger<=203)[0]]
    start = np.where(trigger == 240)[0]
    for ti in range(len(epoch_data)):
        epoch_data[ti] = data[:, start[ti]:start[ti]+n_timepoint]

    return epoch_data[:,:,t[0]:t[1]], label, ch_names


# 特征提取
def func_CSP(data, W, nbFilterPairs):
    features = np.zeros((2 * nbFilterPairs))
    Filtered = W[np.r_[:nbFilterPairs, -nbFilterPairs:0]]
    projectedTrial = np.dot(Filtered, data)
    variances = np.var(projectedTrial, 1)
    for i in range(len(variances)):
        features[i] = np.log(variances[i])
    return features


# 滤波
def band_Filter(data):
    nyquist = 125
    frange = [f_low, f_high]
    b, a = signal.butter(4, np.array(frange)/nyquist, 'bandpass')
    for iChan in range(data.shape[0]):
        data[iChan, :] = signal.filtfilt(b, a, data[iChan, :])
    return data

data, label, _ = load(sub)
n_trials = data.shape[0]
n_channels = data.shape[1]
n_timepoints = data.shape[2]
for ti in range(n_trials):
    data[ti] = band_Filter(data[ti])












