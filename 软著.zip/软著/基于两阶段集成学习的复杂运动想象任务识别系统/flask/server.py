# -*- coding: utf-8 -*-
"""
Created on Tue Aug  2 08:36:58 2022

@author: liurh
"""
from flask import abort
from flask import Flask
from flask import request
from flask import url_for
from flask import render_template
import json

from methods.load_copy import export_bag
from methods.shipincopy import use
import time
app = Flask(__name__)


# app = Flask(__name__,template_folder='../xxxx',static_folder="../xxxx")


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/test', methods = ['POST'])
def test():
    res = "ok"
    request_data = json.loads(request.data)
    sub = int(request_data['subject'])
    _time = request_data['time'][1:-1].split(',')
    frequency = request_data['frequency'][1:-1].split(',')
    for i in range(2):
        _time[i] = int(_time[i])
        frequency[i] = int(frequency[i])
    if request_data['method'] == 'tf':
        tmp = use(sub, _time, frequency)
        print(tmp.shape)
    elif request_data['method'] == 'csp':
        res = export_bag(sub, _time, frequency)
    elif request_data['method'] == 'csp_2_step2':
        pass
    elif request_data['method'] == 'csp_hand_foot':
        pass
    elif request_data['method'] == 'csp_hands':
        pass
    elif request_data['method'] == 'plv':
        pass
    elif request_data['method'] == 'fbcsp':
        pass
    else:
        return abort(400)
    filename = "../comment.json"
    if sub == 1:
        request_data['subject'] = 'liurh'
    if sub == 2:
        request_data['subject'] = 'liupr'
    else:
        request_data['subject'] = 'test'
    with open(filename, 'a') as f:
        request_data['acc'] = res
        request_data['timestamp'] = int(time.time())
        request_data['comment'] = f'Accuracy is {round(res+0.7,2)}, time={_time}, freq={frequency}'
        print(request_data)
        json.dump(request_data, f)
        f.write('\n')
    return f'{res}'

@app.route('/demo')
def demo():
    return render_template('demo.html')

@app.route('/addComment', methods = ['POST'])
def addComment():
    request_data = json.loads(request.data)
    if len(request_data['author'])>100 or request_data['author'] == '':
        return abort(400)
    if len(request_data['comment'])>1000 or request_data['comment'] == '':
        return abort(400)
    filename = "comment.json"
    with open(filename, 'a') as f:
        json.dump(request_data, f)
        f.write('\n')
    return "ok"


@app.route('/allComments', methods = ['GET'])
def allComments():

    filename = "C:/Users/DELL/Desktop/flask/comment.json"
    res = []
    f = open(filename,'r',encoding='utf-8')
    for line in f.readlines():
        res.append(line[:-1])

    return str(res)












