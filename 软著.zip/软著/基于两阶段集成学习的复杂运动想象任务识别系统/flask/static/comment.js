
var comments = [];
function get_comments(data){
	//	transfer string to json-array
	data = eval(data)
	for (var i = 0; i<data.length; i++){
		//console.log(data[i]);
		data[i] = JSON.parse(data[i]);
	}
	return data;
}

var CommentContainer = React.createClass({
    getInitialState: function () {
        return {data: []};
    },
	update_data: function () {
		let queryStringRequest = new Request('http://127.0.0.1:5000/allComments', {
			method: 'get'
		})
		fetch(queryStringRequest).then(res => {
	        res.text().then((data)=>{
		       	comments = get_comments(data);
		       	// console.log(comments);
	    		this.setState({data: comments});
			})
		})
	},
 componentDidMount: function () {
     // supposedly logic for ajax
	    this.intervalId = setInterval(() => {
		    this.update_data();
		}, 2000);
 },
 
    // componentWillMount: function () {
        // this.update_data();
    // },

    handleCommentSubmit: function (comment) {
        var comments = this.state.data;
        this.setState({
            data: comments.concat(comment)
        });
//      let queryStringRequest = new Request('http://127.0.0.1:5000/addComment', {
//  		method: 'post',
//  		body :JSON.stringify(comment)
//  	})
		let queryStringRequest = new Request('http://127.0.0.1:5000/test', {
    		method: 'post',
    		body :JSON.stringify(comment)
    	})
    	fetch(queryStringRequest).then(res => {
        	// console.log(res)
    })
    },
    render: function () {
    	
        return (
            <div id="comment-container" className="content-container">
                <div className="container">
                    <CommentList comments={this.state.data} />
                    <CommentForm onCommentSubmit={this.handleCommentSubmit} />
                </div>
            </div>
        );
    }
});

var CommentList = React.createClass({
    render: function () {
        var commentsArray = this.props.comments.map(function (item) {
            return (
                <CommentItem subject={item.subject}
                    timestamp={item.timestamp}
                    comment={item.comment} />
            );
        });
        
        return (
            <ul id="comment-list" className="list-unstyled">
                {commentsArray}
            </ul>
        );
    }
});

var CommentItem = React.createClass({
    render: function () {
        var date = new Date(this.props.timestamp),
            dateStr,
            subject = this.props.subject,
            commt = this.props.comment;
        	
        if (subject == '') {
            subject = 'Anonymous';
        }

        function padZero (integer) {
            return (integer < 10 ? '0' : '') + integer;
        }
        
        dateStr = padZero(date.getDate()) + '/' + padZero(date.getMonth() + 1) +
            '/' + date.getFullYear() + ' ' + padZero(date.getHours()) + ':' +
            padZero(date.getMinutes());

        return (
            <li>
                <b>{subject}</b>{' '}
                <small className="text-muted">{dateStr}</small>
                
                <div className="comment-list-comment">
                    {this.props.comment}
					{this.props.acc}
                </div>
            </li>
        );
    }
});


var CommentForm = React.createClass({
    handleSubmit: function (e) {
        e.preventDefault();
        // console.log(this.refs);
        var subject = React.findDOMNode(this.refs.subject),
            method = React.findDOMNode(this.refs.method),
            time = React.findDOMNode(this.refs.time),
            frequency = React.findDOMNode(this.refs.frequency),
            
            authorVal = subject.value.trim(),
            methodVal = method.value.trim(),
   			timeVal = time.value.trim(),
   			frequencyVal = frequency.value.trim();

        if (authorVal) {
            subject.value = method.value = '';
            
            this.props.onCommentSubmit({
                subject: authorVal,
                method: methodVal,
                time : timeVal,
                frequency : frequencyVal
            });
        }
        
        return;
    },
    render: function () {
        return (
            <form className="form-horizontal"   onSubmit={this.handleSubmit}>
            
                <div className="form-group">
                    <label className="col-sm-3 control-label">Subject</label>
                    <div className="col-sm-9">
                        <input type="text" className="form-control" ref="subject" />
                    </div>
                </div>
                
                <div className="form-group">
                    <label className="col-sm-3 control-label">Methods</label>
                    <div className="col-sm-9">
                    	<input type="text" className="form-control" ref="method" />
                    </div>
                </div>

				<div className="form-group">
                    <label className="col-sm-3 control-label">Time</label>
                    <div className="col-sm-9">
                    	<input type="text" className="form-control" ref="time" />
                    </div>
                </div>

				<div className="form-group">
                    <label className="col-sm-3 control-label">Frequency</label>
                    <div className="col-sm-9">
                    	<input type="text" className="form-control" ref="frequency" />
                    </div>
                </div>

                <div className="form-group">
                    <div className="col-sm-3 col-sm-offset-3">
                        <button type="submit" className="btn btn-primary btn-block">Submit</button>
                    </div>
                </div>
            </form>
        );
    }
});
