var NavContainer = React.createClass({
    render: function () {
        return (
            <div className="navbar navbar-inverse navbar-fixed-top">
                <div className="container">
                    <div id="nav" className="text-center">
                        <a id="nav-link" href="#/about">EEG laboratory</a>
                    </div>
                </div>
            </div>
        );
    }
});
